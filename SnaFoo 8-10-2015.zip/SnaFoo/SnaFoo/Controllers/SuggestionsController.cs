﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Configuration;

namespace SnaFoo.Controllers
{
    public class SuggestionsController : Controller
    {
        // GET: Suggestions
        public ActionResult Index()
        {
            getOptionalSnacks();
           
            return View();
        }

        private void getOptionalSnacks()
        {
            Models.SnackModel snack = new Models.SnackModel();
            List<Models.SnackModel> optionalSnacks = snack.getOptionalSnackList();
            if(optionalSnacks == null)
            {
                optionalSnacks = new List<Models.SnackModel>();
            }
            List<SelectListItem> snackList = new List<SelectListItem>();
            foreach (Models.SnackModel s in optionalSnacks)
            {
                snackList.Add(new SelectListItem { Text = s.Name, Value = s.Id.ToString() });
            }
            ViewBag.snacks = snackList;            
        }
       
        // POST: Suggestions/Suggest
        public ActionResult Suggest(Models.SuggestionModel suggestion)
        {
            bool useCookies = bool.Parse(ConfigurationManager.AppSettings["UseCookies"]);
            if (useCookies)
            {
                HttpCookie cookie = Request.Cookies["Suggestion"];
                int num_suggestions = 0;
                if (cookie == null)
                {
                    cookie = new HttpCookie("Suggestion");
                    DateTime dtNow = DateTime.Now;

                    int min_timeout = int.Parse(ConfigurationManager.AppSettings["Cookie_Default_Timeout"]);

                    TimeSpan tsMinute = new TimeSpan(0, 0, min_timeout, 0);
                    cookie.Expires = dtNow + tsMinute;
                }
                else
                {
                    num_suggestions = cookie.Value.Length;
                    if (cookie.Value.Length >= 2)
                    {
                        ViewBag.Error = "More than 3 suggestions this month.";
                        return View("Error");
                    }
                }
                if (cookie.Value != null)
                {

                    cookie.Value = 1 + cookie.Value;
                }
                else
                {
                    cookie.Value = "";
                }
           
                int s_id = suggestion.suggest(suggestion);
                if (s_id <= 0)
                {
                    ViewBag.Error = " There was an error suggestion that which already exists?  Something went wrong.";
                    return View("Error");
                }
            
                Response.Cookies.Add(cookie);
            }
            else
            {
                //TODO: Use some other form of suggestion tracking to make sure the user does not suggest more than 3 a month.
                int s_id = suggestion.suggest(suggestion);
                if (s_id <= 0)
                {
                    ViewBag.Error = " There was an error suggestion that which already exists?  Something went wrong.";
                    return View("Error");
                }
            }
            return RedirectToAction("Index");
        }
        // POST: Suggestions/Submit
        public ActionResult Submit(Models.SuggestionModel suggestion)
        {
            bool useCookies = bool.Parse(ConfigurationManager.AppSettings["UseCookies"]);

            if (useCookies)
            {
                if (suggestion.Name == null)
                {
                    ViewBag.Error = "Please Enter a Name.";
                    return View("Error");
                }
                if (suggestion.Location == null)
                {
                    ViewBag.Error = "Please Enter a Location.";
                    return View("Error");
                }
                HttpCookie cookie = Request.Cookies["Suggestion"];
                int num_suggestions = 0;
                if (cookie == null)
                {
                    cookie = new HttpCookie("Suggestion");
                    DateTime dtNow = DateTime.Now;

                    int min_timeout = int.Parse(ConfigurationManager.AppSettings["Cookie_Default_Timeout"]);

                    TimeSpan tsMinute = new TimeSpan(0, 0, min_timeout, 0);
                    cookie.Expires = dtNow + tsMinute;
                }
                else
                {
                    num_suggestions = cookie.Value.Length;
                    if (cookie.Value.Length >= 2)
                    {
                        ViewBag.Error = "More than 3 suggestions this Month.";
                        return View("Error");
                    }
                }
                if (cookie.Value != null)
                {

                    cookie.Value = 1 + cookie.Value;
                }
                else
                {
                    cookie.Value = "";
                }
                Models.SnackModel s = suggestion.suggest_new(suggestion);
                if (s.Id <= 0)
                {
                    ViewBag.Error = s.Id + " " + s.Name;
                    return View("Error");
                }

                Response.Cookies.Add(cookie);
            }
            else
            {
                //TODO: Use some other form of suggestion tracking to make sure the user does not suggest more than 3 a month.

                Models.SnackModel s = suggestion.suggest_new(suggestion);
                if (s.Id <= 0)
                {
                    ViewBag.Error = s.Id + " " + s.Name;
                    return View("Error");
                }
            }
            return RedirectToAction("Index");
        }
       
    }
}
