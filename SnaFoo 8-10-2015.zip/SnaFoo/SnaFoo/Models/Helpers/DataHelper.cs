﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;

using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json;

namespace SnaFoo.Models
{
    public class DataHelper
    {
        private string connection_string;
        private static string api_key;
        private static List<SnackModel> snack_list;
        private static SnackModel new_snack;

        public DataHelper()
        {
            connection_string = ConfigurationManager.ConnectionStrings["SnaFooDB"].ConnectionString;
            api_key = ConfigurationManager.AppSettings["APIKEY"];
            snack_list = new List<SnackModel>();
            new_snack = new SnackModel();
        }
  
        public int suggestSnack(SuggestionModel s)
        {
            snack_list = getSnacks();
            int snackId = 0;
            foreach(SnackModel snack in snack_list)
            {
                if(snack.Name == s.Name)
                {
                    snackId = snack.Id;
                }
            }

            int rows = 0;
            using (var cn = new SqlConnection())
            {
                cn.ConnectionString = connection_string;
                cn.Open();

                string query = @"INSERT INTO [Suggestions] VALUES(" + snackId.ToString() + ", GETDATE())";
                var com = new SqlCommand(query, cn);
                rows = com.ExecuteNonQuery();


                cn.Close();
            }
            return rows;
        }

        public int voteForSnack(int snackId)
        {
            int rows = 0;
            using (var cn = new SqlConnection())
            {
                cn.ConnectionString = connection_string;
                cn.Open();

                string query = @"INSERT INTO [Votes] VALUES(" + snackId.ToString() + ", GETDATE())";
                var com = new SqlCommand(query, cn);
                rows = com.ExecuteNonQuery();


                cn.Close();
            }
            return rows;
        }

      
        public List<VoteModel> getVotes()
        {
            List<VoteModel> votes = new List<VoteModel>();
            using (var cn = new SqlConnection())
            {
                cn.ConnectionString = connection_string;
                cn.Open();

                string query = @"Select SnackId, Count(VotedOn) as Count FROM [Votes] WHERE SnackId > 0 Group By SnackId ORDER BY Count(VotedOn) DESC";
                var com = new SqlCommand(query, cn);

                SqlDataReader reader = com.ExecuteReader();
                while (reader.Read())
                {
                 //   int id = (int)reader[0];
                    int snackId = (int)reader[0];
                    int Count = (int)reader[1];

                    VoteModel v = new VoteModel();
                    v.SnackId = snackId;
                    v.VoteCount = Count;
                    votes.Add(v);
                }
                cn.Close();
            }
                return votes;
        }

        public List<SuggestionModel> getSuggestions()
        {
            List<SuggestionModel> suggestions = new List<SuggestionModel>();
            using (var cn = new SqlConnection())
            {
                cn.ConnectionString = connection_string;
                cn.Open();

                string query = @"Select * From [Suggestions]";
                var com = new SqlCommand(query, cn);

                SqlDataReader reader = com.ExecuteReader();
                while (reader.Read())
                {
                    int id = (int)reader[0];
                    int snackId = (int)reader[1];
                    DateTime suggestedOn = (DateTime)reader[2];

                    SuggestionModel s = new SuggestionModel();
                   // s.snackId = snackId;
                   // s.suggestedOn = suggestedOn;
                    suggestions.Add(s);
                }
                cn.Close();
            }
            return suggestions;
        }
        /**
        public int suggest(int id)
        {
            int rows = 0;
            using (var cn = new SqlConnection())
            {
                cn.ConnectionString = connection_string;
                cn.Open();

                string query = @"INSERT INTO [Suggestions] VALUES(" + id.ToString() + ", GETDATE())";
                var com = new SqlCommand(query, cn);
                rows = com.ExecuteNonQuery();
            
                cn.Close();
            }
            return rows;
        }

        public int vote(int id)
        {
            int rows = 0;
            using (var cn = new SqlConnection())
            {
                cn.ConnectionString = connection_string;
                cn.Open();

                string query = @"INSERT INTO [Votes] VALUES(" + id.ToString() + ", GETDATE())";
                var com = new SqlCommand(query, cn);
                rows= com.ExecuteNonQuery();
            }
            return rows;
        }
        **/
        public List<SnackModel> getSnacks()
        {
            GetSnacks().Wait();
            return snack_list;
        }

        public SnackModel postSnacks(string Name, string Location)
        {
            PostSnacks(Name, Location).Wait();
            return new_snack;
        }

        private static async Task GetSnacks()
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://api-snacks.nerderylabs.com/v1/snacks");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var response = await client.GetAsync("snacks/?ApiKey="+api_key).ConfigureAwait(continueOnCapturedContext: false);
                if (response.IsSuccessStatusCode)
                {
                    string result = response.Content.ReadAsStringAsync().Result;
                    snack_list = JsonConvert.DeserializeObject<List<SnackModel>>(result);
                }
                else 
                {
                    snack_list = null;
                }


            }
        }

        private static async Task PostSnacks(string Name, string Location)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://api-snacks.nerderylabs.com/v1/snacks");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpContent content = new StringContent(Newtonsoft.Json.JsonConvert.SerializeObject(new { name = Name, location = Location }), Encoding.UTF8, "application/json");

                var response = await client.PostAsync("snacks/?ApiKey="+api_key, content).ConfigureAwait(continueOnCapturedContext: false);
                if (response.IsSuccessStatusCode)
                {
                    string result = response.Content.ReadAsStringAsync().Result;
                    new_snack = JsonConvert.DeserializeObject<SnackModel>(result);
                }
                else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                {
                    new_snack = new SnackModel();
                    new_snack.Id = -401;
                    new_snack.Name = "Unauthorized";
                    
                }
                else if(response.StatusCode == System.Net.HttpStatusCode.BadRequest){
                    new_snack = new SnackModel();
                    new_snack.Id = -400;
                    new_snack.Name = "Bad Request";
                }
                else if (response.StatusCode == System.Net.HttpStatusCode.Conflict)
                {
                    new_snack = new SnackModel();
                    new_snack.Id = -409;
                    new_snack.Name = "Conflict";
                }
                else
                {
                    new_snack = new SnackModel();
                    new_snack.Id = -1;
                    new_snack.Name = "Cannot connect.";
                }

               
            }
        }

    }
}