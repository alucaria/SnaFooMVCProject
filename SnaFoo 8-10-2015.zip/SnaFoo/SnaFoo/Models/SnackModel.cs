﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
namespace SnaFoo.Models
{
    public class SnackModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public bool Optional { get; set; }
        public string PurchaseLocations { get; set; }
        public int PurchaseCount { get; set; }
        public string LastPurchaseDate { get; set; }

        public List<SnackModel> getSnackList()
        {
            DataHelper dh = new DataHelper();
            List<SnackModel> snacks = dh.getSnacks();
            return snacks;
        }
        public List<SnackModel> getOptionalSnackList()
        {
            DataHelper dh = new DataHelper();
            List<SnackModel> snacks = dh.getSnacks();
            if (snacks == null)
            {
                return null;
            }
            List<SnackModel> optionalSnacks = new List<SnackModel>();
            foreach(SnackModel s in snacks)
            {
                if(s.Optional == true)
                {
                    optionalSnacks.Add(s);
                }
            }

            return optionalSnacks;
        }

        public List<SnackModel> getAlwaysPurchasedSnackList()
        {
            DataHelper dh = new DataHelper();
            List<SnackModel> snacks = dh.getSnacks();
            if (snacks== null)
            {
                return null;
            }
            List<SnackModel> alwaysPurchased = new List<SnackModel>();
            foreach (SnackModel s in snacks)
            {
                if (s.Optional == false)
                {
                    alwaysPurchased.Add(s);
                }
            }

            return alwaysPurchased;
        }

        public int voteForSnack(int id)
        {
            DataHelper dh = new DataHelper();
            return dh.voteForSnack(id);
            
        }

        public List<SnackModel> getShoppingList()
        {
            DataHelper dh = new DataHelper();
            List<SnackModel> snackList = dh.getSnacks();
            List<SnackModel> shoppingList = new List<SnackModel>();
            foreach (SnackModel s in snackList)
            {
                if (s.Optional == false)
                {
                    shoppingList.Add(s);
                }
            }

            List<VoteModel> votes = dh.getVotes();

            foreach (VoteModel v in votes)
            {
                foreach (SnackModel s in snackList)
                {
                    if (v.SnackId == s.Id && s.Optional == true)
                    {
                        shoppingList.Add(s);
                        break;
                    }
                }
                if (shoppingList.Count == 10)
                {
                    break;
                }
            }
           
            return shoppingList;

        }
    }
}