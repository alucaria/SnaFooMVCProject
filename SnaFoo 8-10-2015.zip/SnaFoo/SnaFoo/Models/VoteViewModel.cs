﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SnaFoo.Models
{
    public class VoteViewModel
    {
        public int SnackId { get; set; }
        public string Name { get; set; }
        public string LastPurchaseDate { get; set; }
        public int Votes { get; set; }
        public bool Optional { get; set; }

        public List<VoteViewModel> getModel()
        {
            DataHelper dh = new DataHelper();
            List<VoteViewModel> model = new List<VoteViewModel>();
            List<SnackModel> snacks = dh.getSnacks();

            List <VoteModel> votes = dh.getVotes();
            foreach(SnackModel s in snacks)
            {
                VoteViewModel m = new VoteViewModel();
                m.SnackId = s.Id;
                m.Name = s.Name;
                m.Optional = s.Optional;
                m.LastPurchaseDate = s.LastPurchaseDate;

                int num_votes = 0;
                foreach(VoteModel v in votes)
                {
                    if (v.SnackId == s.Id)
                    {
                        num_votes = v.VoteCount;
                        break;
                    }
                }
                m.Votes = num_votes;
                model.Add(m);

            }
            return model;
        }
    }
}