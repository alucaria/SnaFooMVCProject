﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SnaFoo.Models
{
    public class SuggestionModel
    {
        public string Name { get; set; }
        
        public string Location { get; set; }
        public string StreetAddress { get; set; }
        public string StreetAddress2 { get; set; }
        public string City { get; set; }
        public string StateProvince { get; set; }
        public string Country { get; set; }
        public string Postal_code { get; set; }
        public decimal Latitude { get; set; }
        public decimal Longitute { get; set; }


        public SnackModel suggest_new(SuggestionModel s)
        {
            DataHelper helper = new DataHelper();
            SnackModel snack =  helper.postSnacks(s.Name, s.Location);
            helper.suggestSnack(s);
            return snack;

        }
        public int suggest(SuggestionModel s)
        {
            DataHelper helper = new DataHelper();
            return helper.suggestSnack(s);
        }
    }
}