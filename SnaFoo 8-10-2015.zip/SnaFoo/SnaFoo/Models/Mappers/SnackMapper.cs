﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SnaFoo.Models.Mappers
{
    public class SnackMapper
    {
    }
}