﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Configuration;

namespace SnaFoo.Controllers
{
    public class VotingController : Controller
    {
        // GET: Voting
        public ActionResult Index()
        {
            //get list
            List<Models.VoteViewModel> snacksList = getVoteViewModelList();


            return View(snacksList);
        }
        private List<Models.VoteViewModel> getVoteViewModelList()
        {
            Models.VoteViewModel vvm = new Models.VoteViewModel();
            return vvm.getModel();
        }

       // [HttpPost]
        public ActionResult Vote(int id, FormCollection collection)
        {
            bool useCookies = bool.Parse(ConfigurationManager.AppSettings["UseCookies"]);

            if (useCookies)
            {
                HttpCookie cookie = Request.Cookies["Vote"];
                int num_suggestions = 0;
                if (cookie == null)
                {
                    cookie = new HttpCookie("Vote");
                    DateTime dtNow = DateTime.Now;

                    int min_timeout = int.Parse(ConfigurationManager.AppSettings["Cookie_Default_Timeout"]);
                    TimeSpan tsMinute = new TimeSpan(0, 0, min_timeout, 0);
                    cookie.Expires = dtNow + tsMinute;
                }
                else
                {
                    num_suggestions = cookie.Value.Length;
                    if (num_suggestions >= 3)
                    {
                        ViewBag.Error = "More than 3 votes this Month.";
                        return View("Error");
                    }
                }
                if (cookie.Value != null)
                {
                    cookie.Value = 1 + cookie.Value;
                }
                else
                {
                    cookie.Value = "";
                }
                Models.SnackModel s = new Models.SnackModel();

                int rows = s.voteForSnack(id);

                if (rows <= 0)
                {
                    ViewBag.Error = "There was an error making your vote!";
                    return View("Error");
                }

                Response.Cookies.Add(cookie);
            }
            else
            {
                //TODO: Use some other form of suggestion tracking to make sure the user does not suggest more than 3 a month.
                Models.SnackModel s = new Models.SnackModel();
                int rows = s.voteForSnack(id);
                if (rows <= 0)
                {
                    ViewBag.Error = "There was an error making your vote!";
                    return View("Error");
                }
            }
            return RedirectToAction("Index");
        }
    }
}
