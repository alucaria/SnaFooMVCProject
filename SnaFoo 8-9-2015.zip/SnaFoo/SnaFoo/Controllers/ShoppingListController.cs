﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SnaFoo.Controllers
{
    public class ShoppingListController : Controller
    {
        // GET: ShoppingList
        public ActionResult Index()
        {
            List<Models.SnackModel> snacks = getShoppingList();
            return View(snacks);
        }

        private List<Models.SnackModel> getShoppingList()
        {
            Models.SnackModel snack = new Models.SnackModel();
            return  snack.getShoppingList();
        }
      
    }
}
